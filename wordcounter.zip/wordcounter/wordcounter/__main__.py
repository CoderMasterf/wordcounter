import sys

def count_words(text: str) -> int:
    """统计文本中的单词数量"""
    return len(text.split())

if __name__ == "__main__":
    if len(sys.argv) > 1:
        text = " ".join(sys.argv[1:])
        print(f"单词数量: {count_words(text)}")
    else:
        print("请输入一句话。例如：")
        print("python -m wordcounter 'Hello world this is a test'")
