from wordcounter.__main__ import count_words

def test_count_words():
    assert count_words("Hello world") == 2
    assert count_words("AI generates content") == 3
